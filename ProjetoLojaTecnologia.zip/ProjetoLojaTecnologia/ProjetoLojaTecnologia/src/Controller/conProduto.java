/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Conexao;
import Model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Operacoes sobre a tabela TBPRODUTO. Regras invalidas lancam
 * IllegalArgumentException; erros SQL seguem para a View por SQLException.
 *
 * @author LABINFO
 */
public class conProduto {

    private static final int MYSQL_CHAVE_ESTRANGEIRA = 1451;

    private void validar(Produto produto){
        if (produto.getNomeProduto() == null || produto.getNomeProduto().trim().isEmpty()) {
            throw new IllegalArgumentException("Informe o nome do produto.");
        }
        if (produto.getNomeProduto().length() > 50) {
            throw new IllegalArgumentException("O nome aceita no maximo 50 caracteres.");
        }
        if (produto.getCategoriaProduto() != null && produto.getCategoriaProduto().length() > 40) {
            throw new IllegalArgumentException("A categoria aceita no maximo 40 caracteres.");
        }
        if (produto.getMarcaProduto() != null && produto.getMarcaProduto().length() > 40) {
            throw new IllegalArgumentException("A marca aceita no maximo 40 caracteres.");
        }
        if (produto.getValorProduto() < 0) {
            throw new IllegalArgumentException("O valor nao pode ser negativo.");
        }
        if (produto.getValorProduto() > 99999999.99) {
            throw new IllegalArgumentException("O valor maximo aceito e 99999999.99.");
        }
        if (produto.getQuantidadeProduto() < 0) {
            throw new IllegalArgumentException("A quantidade nao pode ser negativa.");
        }
    }

    private Produto montar(ResultSet rs) throws SQLException {
        Produto prod = new Produto();
        prod.setCodigoProduto(rs.getInt("idprod"));
        prod.setNomeProduto(rs.getString("nomeprod"));
        prod.setCategoriaProduto(rs.getString("categprod"));
        prod.setMarcaProduto(rs.getString("marcprod"));
        prod.setQuantidadeProduto(rs.getInt("qtdprod"));
        prod.setValorProduto(rs.getDouble("precoprod"));
        return prod;
    }

    /** Insere o produto e devolve o idprod gerado. */
    public int Cadastrar(Produto produto) throws SQLException {
        validar(produto);
        String sql = "insert into TBPRODUTO(nomeprod, categprod, marcprod, qtdprod, precoprod)"
                + " values(?, ?, ?, ?, ?)";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            caminhao.setString(1, produto.getNomeProduto().trim());
            caminhao.setString(2, produto.getCategoriaProduto());
            caminhao.setString(3, produto.getMarcaProduto());
            caminhao.setInt(4, produto.getQuantidadeProduto());
            caminhao.setDouble(5, produto.getValorProduto());

            caminhao.executeUpdate();
            try (ResultSet chaves = caminhao.getGeneratedKeys()) {
                return chaves.next() ? chaves.getInt(1) : 0;
            }
        }
    }

    /** @return true se o registro existia e foi alterado */
    public boolean Alterar(Produto produto) throws SQLException {
        validar(produto);
        String sql = "update TBPRODUTO set nomeprod = ?, categprod = ?, marcprod = ?,"
                + " qtdprod = ?, precoprod = ? where idprod = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql)) {

            caminhao.setString(1, produto.getNomeProduto().trim());
            caminhao.setString(2, produto.getCategoriaProduto());
            caminhao.setString(3, produto.getMarcaProduto());
            caminhao.setInt(4, produto.getQuantidadeProduto());
            caminhao.setDouble(5, produto.getValorProduto());
            caminhao.setInt(6, produto.getCodigoProduto());

            return caminhao.executeUpdate() > 0;
        }
    }

    /** @return true se o registro existia e foi excluido */
    public boolean Excluir(int id) throws SQLException {
        String sql = "delete from TBPRODUTO where idprod = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql)) {

            caminhao.setInt(1, id);
            return caminhao.executeUpdate() > 0;
        } catch (SQLException ex) {
            if (ex.getErrorCode() == MYSQL_CHAVE_ESTRANGEIRA) {
                throw new IllegalArgumentException("Este produto consta em vendas e nao pode ser excluido.");
            }
            throw ex;
        }
    }

    /** @return o produto ou null quando o codigo nao existe */
    public Produto BuscarId(int id) throws SQLException {
        String sql = "select * from TBPRODUTO where idprod = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql)) {

            caminhao.setInt(1, id);
            try (ResultSet rs = caminhao.executeQuery()) {
                return rs.next() ? montar(rs) : null;
            }
        }
    }

    public List<Produto> Listar() throws SQLException {
        List<Produto> lista = new ArrayList<>();
        String sql = "select * from TBPRODUTO order by idprod";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql);
             ResultSet rs = caminhao.executeQuery()) {

            while (rs.next()) {
                lista.add(montar(rs));
            }
        }
        return lista;
    }
}
