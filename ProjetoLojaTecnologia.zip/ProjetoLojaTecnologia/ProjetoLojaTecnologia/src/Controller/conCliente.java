/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Cliente;
import Model.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Operacoes sobre a tabela TBCLIENTE. Regras invalidas lancam
 * IllegalArgumentException; erros SQL seguem para a View por SQLException.
 *
 * @author LABINFO
 */
public class conCliente {

    private static final int MYSQL_DUPLICADO = 1062;
    private static final int MYSQL_CHAVE_ESTRANGEIRA = 1451;

    private void validar(Cliente cliente){
        if (cliente.getNomeCliente() == null || cliente.getNomeCliente().trim().isEmpty()) {
            throw new IllegalArgumentException("Informe o nome do cliente.");
        }
        if (cliente.getNomeCliente().length() > 100) {
            throw new IllegalArgumentException("O nome aceita no maximo 100 caracteres.");
        }
        if (cliente.getCpfCliente() == null
                || !cliente.getCpfCliente().matches("\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}")) {
            throw new IllegalArgumentException("Informe o CPF no formato 000.000.000-00.");
        }
        if (cliente.getTelefoneCliente() != null && cliente.getTelefoneCliente().length() > 15) {
            throw new IllegalArgumentException("O telefone aceita no maximo 15 caracteres.");
        }
        if (cliente.getEmailCliente() != null && cliente.getEmailCliente().length() > 100) {
            throw new IllegalArgumentException("O e-mail aceita no maximo 100 caracteres.");
        }
        if (cliente.getEnderecoCliente() != null && cliente.getEnderecoCliente().length() > 150) {
            throw new IllegalArgumentException("O endereco aceita no maximo 150 caracteres.");
        }
    }

    private Cliente montar(ResultSet rs) throws SQLException {
        Cliente cli = new Cliente();
        cli.setCodigoCliente(rs.getInt("idcliente"));
        cli.setNomeCliente(rs.getString("nomecliente"));
        cli.setCpfCliente(rs.getString("cpfcliente"));
        cli.setTelefoneCliente(rs.getString("telcliente"));
        cli.setEmailCliente(rs.getString("emailcliente"));
        cli.setEnderecoCliente(rs.getString("endcliente"));
        return cli;
    }

    /** Insere o cliente e devolve o idcliente gerado. */
    public int Cadastrar(Cliente cliente) throws SQLException {
        validar(cliente);
        String sql = "insert into TBCLIENTE(nomecliente, cpfcliente, telcliente,"
                + " emailcliente, endcliente) values(?, ?, ?, ?, ?)";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            caminhao.setString(1, cliente.getNomeCliente().trim());
            caminhao.setString(2, cliente.getCpfCliente());
            caminhao.setString(3, cliente.getTelefoneCliente());
            caminhao.setString(4, cliente.getEmailCliente());
            caminhao.setString(5, cliente.getEnderecoCliente());

            caminhao.executeUpdate();
            try (ResultSet chaves = caminhao.getGeneratedKeys()) {
                return chaves.next() ? chaves.getInt(1) : 0;
            }
        } catch (SQLException ex) {
            if (ex.getErrorCode() == MYSQL_DUPLICADO) {
                throw new IllegalArgumentException("Ja existe um cliente com este CPF.");
            }
            throw ex;
        }
    }

    /** @return true se o registro existia e foi alterado */
    public boolean Alterar(Cliente cliente) throws SQLException {
        validar(cliente);
        String sql = "update TBCLIENTE set nomecliente = ?, cpfcliente = ?, telcliente = ?,"
                + " emailcliente = ?, endcliente = ? where idcliente = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql)) {

            caminhao.setString(1, cliente.getNomeCliente().trim());
            caminhao.setString(2, cliente.getCpfCliente());
            caminhao.setString(3, cliente.getTelefoneCliente());
            caminhao.setString(4, cliente.getEmailCliente());
            caminhao.setString(5, cliente.getEnderecoCliente());
            caminhao.setInt(6, cliente.getCodigoCliente());

            return caminhao.executeUpdate() > 0;
        } catch (SQLException ex) {
            if (ex.getErrorCode() == MYSQL_DUPLICADO) {
                throw new IllegalArgumentException("Ja existe um cliente com este CPF.");
            }
            throw ex;
        }
    }

    /** @return true se o registro existia e foi excluido */
    public boolean Excluir(int id) throws SQLException {
        String sql = "delete from TBCLIENTE where idcliente = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql)) {

            caminhao.setInt(1, id);
            return caminhao.executeUpdate() > 0;
        } catch (SQLException ex) {
            if (ex.getErrorCode() == MYSQL_CHAVE_ESTRANGEIRA) {
                throw new IllegalArgumentException("Este cliente possui vendas e nao pode ser excluido.");
            }
            throw ex;
        }
    }

    /** @return o cliente ou null quando o codigo nao existe */
    public Cliente BuscarId(int id) throws SQLException {
        String sql = "select * from TBCLIENTE where idcliente = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql)) {

            caminhao.setInt(1, id);
            try (ResultSet rs = caminhao.executeQuery()) {
                return rs.next() ? montar(rs) : null;
            }
        }
    }

    public List<Cliente> Listar() throws SQLException {
        List<Cliente> lista = new ArrayList<>();
        String sql = "select * from TBCLIENTE order by idcliente";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql);
             ResultSet rs = caminhao.executeQuery()) {

            while (rs.next()) {
                lista.add(montar(rs));
            }
        }
        return lista;
    }
}
