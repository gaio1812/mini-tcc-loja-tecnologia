/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Conexao;
import Model.ItemVenda;
import Model.Venda;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Operacoes sobre TBVENDA e TBITEMVENDA. Uma venda e gravada junto com seus
 * itens em uma unica transacao: ou grava tudo, ou nao grava nada. Ao vender, a
 * quantidade e baixada em TBPRODUTO; ao excluir a venda, ela e devolvida.
 *
 * @author LABINFO
 */
public class conVenda {

    public static final String[] FORMAS_PAGAMENTO = {"PIX", "CARTAO", "DINHEIRO"};
    public static final String[] STATUS_VENDA = {"PENDENTE", "CONCLUIDA"};

    private static final int MYSQL_CHAVE_ESTRANGEIRA_FILHA = 1452;

    private void validarCabecalho(Venda venda){
        if (venda.getFormaPagamento() == null
                || !Arrays.asList(FORMAS_PAGAMENTO).contains(venda.getFormaPagamento())) {
            throw new IllegalArgumentException("Escolha uma forma de pagamento valida.");
        }
        if (venda.getStatusVenda() == null
                || !Arrays.asList(STATUS_VENDA).contains(venda.getStatusVenda())) {
            throw new IllegalArgumentException("Escolha um status valido.");
        }
    }

    /**
     * Grava a venda e os itens (TBVENDA + TBITEMVENDA) e baixa o estoque.
     * O valor unitario de cada item e lido de TBPRODUTO e o valor total da
     * venda e calculado aqui, nao confiando em valores vindos da tela.
     *
     * @return o idvenda gerado
     */
    public int Cadastrar(Venda venda, List<ItemVenda> itens) throws SQLException {
        validarCabecalho(venda);
        if (venda.getCodigoCliente() <= 0) {
            throw new IllegalArgumentException("Escolha o cliente da venda.");
        }
        if (itens == null || itens.isEmpty()) {
            throw new IllegalArgumentException("Adicione ao menos um item a venda.");
        }

        String sqlVenda = "insert into TBVENDA(codcliente, formapagamento, statusvenda, valorvenda)"
                + " values(?, ?, ?, 0)";
        String sqlProduto = "select qtdprod, precoprod, nomeprod from TBPRODUTO where idprod = ? for update";
        String sqlItem = "insert into TBITEMVENDA(codvenda, codprod, qtditem, valorunitario)"
                + " values(?, ?, ?, ?)";
        String sqlBaixa = "update TBPRODUTO set qtdprod = qtdprod - ? where idprod = ?";
        String sqlTotal = "update TBVENDA set valorvenda = ? where idvenda = ?";

        try (Connection con = Conexao.conectar()) {
            con.setAutoCommit(false);
            try {
                int idVenda;
                try (PreparedStatement caminhao = con.prepareStatement(sqlVenda, Statement.RETURN_GENERATED_KEYS)) {
                    caminhao.setInt(1, venda.getCodigoCliente());
                    caminhao.setString(2, venda.getFormaPagamento());
                    caminhao.setString(3, venda.getStatusVenda());
                    caminhao.executeUpdate();
                    try (ResultSet chaves = caminhao.getGeneratedKeys()) {
                        chaves.next();
                        idVenda = chaves.getInt(1);
                    }
                }

                BigDecimal total = BigDecimal.ZERO;
                try (PreparedStatement psProduto = con.prepareStatement(sqlProduto);
                     PreparedStatement psItem = con.prepareStatement(sqlItem);
                     PreparedStatement psBaixa = con.prepareStatement(sqlBaixa)) {

                    for (ItemVenda item : itens) {
                        if (item.getQuantidadeItem() <= 0) {
                            throw new IllegalArgumentException("A quantidade de cada item deve ser maior que zero.");
                        }
                        BigDecimal preco;
                        psProduto.setInt(1, item.getCodigoProduto());
                        try (ResultSet rs = psProduto.executeQuery()) {
                            if (!rs.next()) {
                                throw new IllegalArgumentException("Produto " + item.getCodigoProduto() + " nao encontrado.");
                            }
                            if (rs.getInt("qtdprod") < item.getQuantidadeItem()) {
                                throw new IllegalArgumentException("Estoque insuficiente de "
                                        + rs.getString("nomeprod") + " (disponivel: " + rs.getInt("qtdprod") + ").");
                            }
                            preco = rs.getBigDecimal("precoprod");
                        }

                        psItem.setInt(1, idVenda);
                        psItem.setInt(2, item.getCodigoProduto());
                        psItem.setInt(3, item.getQuantidadeItem());
                        psItem.setBigDecimal(4, preco);
                        psItem.executeUpdate();

                        psBaixa.setInt(1, item.getQuantidadeItem());
                        psBaixa.setInt(2, item.getCodigoProduto());
                        psBaixa.executeUpdate();

                        total = total.add(preco.multiply(BigDecimal.valueOf(item.getQuantidadeItem())));
                    }
                }

                try (PreparedStatement caminhao = con.prepareStatement(sqlTotal)) {
                    caminhao.setBigDecimal(1, total);
                    caminhao.setInt(2, idVenda);
                    caminhao.executeUpdate();
                }

                con.commit();
                return idVenda;
            } catch (SQLException | RuntimeException ex) {
                con.rollback();
                if (ex instanceof SQLException
                        && ((SQLException) ex).getErrorCode() == MYSQL_CHAVE_ESTRANGEIRA_FILHA) {
                    throw new IllegalArgumentException("Cliente ou produto inexistente.");
                }
                throw ex;
            }
        }
    }

    /** Altera apenas forma de pagamento e status; itens e valor nao mudam. */
    public boolean Alterar(Venda venda) throws SQLException {
        validarCabecalho(venda);
        String sql = "update TBVENDA set formapagamento = ?, statusvenda = ? where idvenda = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql)) {

            caminhao.setString(1, venda.getFormaPagamento());
            caminhao.setString(2, venda.getStatusVenda());
            caminhao.setInt(3, venda.getCodigoVenda());

            return caminhao.executeUpdate() > 0;
        }
    }

    /** Exclui a venda e seus itens, devolvendo as quantidades ao estoque. */
    public boolean Excluir(int id) throws SQLException {
        String sqlItens = "select codprod, qtditem from TBITEMVENDA where codvenda = ?";
        String sqlDevolve = "update TBPRODUTO set qtdprod = qtdprod + ? where idprod = ?";
        String sqlApagaItens = "delete from TBITEMVENDA where codvenda = ?";
        String sqlApagaVenda = "delete from TBVENDA where idvenda = ?";

        try (Connection con = Conexao.conectar()) {
            con.setAutoCommit(false);
            try {
                try (PreparedStatement psItens = con.prepareStatement(sqlItens);
                     PreparedStatement psDevolve = con.prepareStatement(sqlDevolve)) {
                    psItens.setInt(1, id);
                    try (ResultSet rs = psItens.executeQuery()) {
                        while (rs.next()) {
                            psDevolve.setInt(1, rs.getInt("qtditem"));
                            psDevolve.setInt(2, rs.getInt("codprod"));
                            psDevolve.executeUpdate();
                        }
                    }
                }
                try (PreparedStatement caminhao = con.prepareStatement(sqlApagaItens)) {
                    caminhao.setInt(1, id);
                    caminhao.executeUpdate();
                }
                boolean excluida;
                try (PreparedStatement caminhao = con.prepareStatement(sqlApagaVenda)) {
                    caminhao.setInt(1, id);
                    excluida = caminhao.executeUpdate() > 0;
                }
                if (excluida) {
                    con.commit();
                } else {
                    con.rollback();
                }
                return excluida;
            } catch (SQLException | RuntimeException ex) {
                con.rollback();
                throw ex;
            }
        }
    }

    private Venda montar(ResultSet rs) throws SQLException {
        Venda ven = new Venda();
        ven.setCodigoVenda(rs.getInt("idvenda"));
        ven.setCodigoCliente(rs.getInt("codcliente"));
        ven.setNomeCliente(rs.getString("nomecliente"));
        ven.setDataVenda(rs.getTimestamp("datavenda"));
        ven.setFormaPagamento(rs.getString("formapagamento"));
        ven.setStatusVenda(rs.getString("statusvenda"));
        ven.setValorVenda(rs.getDouble("valorvenda"));
        return ven;
    }

    /** @return a venda ou null quando o codigo nao existe */
    public Venda BuscarId(int id) throws SQLException {
        String sql = "select v.*, c.nomecliente from TBVENDA v"
                + " inner join TBCLIENTE c on c.idcliente = v.codcliente"
                + " where v.idvenda = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql)) {

            caminhao.setInt(1, id);
            try (ResultSet rs = caminhao.executeQuery()) {
                return rs.next() ? montar(rs) : null;
            }
        }
    }

    public List<Venda> Listar() throws SQLException {
        List<Venda> lista = new ArrayList<>();
        String sql = "select v.*, c.nomecliente from TBVENDA v"
                + " inner join TBCLIENTE c on c.idcliente = v.codcliente"
                + " order by v.idvenda";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql);
             ResultSet rs = caminhao.executeQuery()) {

            while (rs.next()) {
                lista.add(montar(rs));
            }
        }
        return lista;
    }

    /** Itens de uma venda (TBITEMVENDA + nome do produto). */
    public List<ItemVenda> ListarItens(int codigoVenda) throws SQLException {
        List<ItemVenda> lista = new ArrayList<>();
        String sql = "select i.*, p.nomeprod from TBITEMVENDA i"
                + " inner join TBPRODUTO p on p.idprod = i.codprod"
                + " where i.codvenda = ? order by i.iditem";

        try (Connection con = Conexao.conectar();
             PreparedStatement caminhao = con.prepareStatement(sql)) {

            caminhao.setInt(1, codigoVenda);
            try (ResultSet rs = caminhao.executeQuery()) {
                while (rs.next()) {
                    ItemVenda item = new ItemVenda();
                    item.setCodigoItem(rs.getInt("iditem"));
                    item.setCodigoVenda(rs.getInt("codvenda"));
                    item.setCodigoProduto(rs.getInt("codprod"));
                    item.setNomeProduto(rs.getString("nomeprod"));
                    item.setQuantidadeItem(rs.getInt("qtditem"));
                    item.setValorUnitario(rs.getDouble("valorunitario"));
                    lista.add(item);
                }
            }
        }
        return lista;
    }
}
