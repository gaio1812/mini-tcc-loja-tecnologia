/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

/**
 * Abre a conexao JDBC com o banco BDLOJATECNOLOGIA (script sql/loja.sql).
 *
 * @author LABINFO
 */
public class Conexao {
    public static Connection conectar() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/BDLOJATECNOLOGIA"
                + "?connectTimeout=5000&socketTimeout=10000";
        String usuario = "root";
        String senha = ""; // ajuste de acordo com o seu MySQL
        // A falha e propagada (throws SQLException): nao retornamos null,
        // para nao esconder a causa original com um NullPointerException.
        return DriverManager.getConnection(url, usuario, senha);
    }
}
