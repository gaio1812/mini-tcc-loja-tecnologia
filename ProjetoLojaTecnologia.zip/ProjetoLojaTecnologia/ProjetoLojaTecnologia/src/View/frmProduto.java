/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Controller.conProduto;
import Model.Produto;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author LABINFO
 */
public class frmProduto extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(frmProduto.class.getName());

    /**
     * Creates new form frmProduto
     */
    public frmProduto() {
        initComponents();
        inicio();
        listar();
    }
    Produto objProd = new Produto();
    conProduto objConProd = new conProduto();
    private DefaultTableModel modeloTabela;

    /**
     * Monta a tela. Ao contrario das telas criadas no modo Design, este
     * codigo foi escrito a mao: edite-o diretamente no modo Source.
     */
    private void initComponents() {

        setTitle("Cadastro de Produtos");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1 = new javax.swing.JLabel("Cadastro de Produtos");
        jLabel1.setFont(jLabel1.getFont().deriveFont(java.awt.Font.BOLD, 18f));

        txtCodigoProduto = new javax.swing.JTextField(8);
        txtNomeProduto = new javax.swing.JTextField(24);
        txtCategoriaProduto = new javax.swing.JTextField(24);
        txtMarcaProduto = new javax.swing.JTextField(24);
        txtValorProduto = new javax.swing.JTextField(10);
        txtQuantidadeProduto = new javax.swing.JTextField(10);
        btnBuscar = new javax.swing.JButton("BUSCAR");
        btnNovo = new javax.swing.JButton("NOVO");
        btnSalvar = new javax.swing.JButton("SALVAR");
        btnAlterar = new javax.swing.JButton("ALTERAR");
        btnExcluir = new javax.swing.JButton("EXCLUIR");
        btnListar = new javax.swing.JButton("LISTAR");
        btnLimpar = new javax.swing.JButton("LIMPAR");

        txtCodigoProduto.addActionListener(this::btnBuscarActionPerformed);
        btnBuscar.addActionListener(this::btnBuscarActionPerformed);
        btnNovo.addActionListener(this::btnNovoActionPerformed);
        btnSalvar.addActionListener(this::btnSalvarActionPerformed);
        btnAlterar.addActionListener(this::btnAlterarActionPerformed);
        btnExcluir.addActionListener(this::btnExcluirActionPerformed);
        btnListar.addActionListener(this::btnListarActionPerformed);
        btnLimpar.addActionListener(this::btnLimparActionPerformed);

        modeloTabela = new DefaultTableModel(new Object[]{"Cód. Prod.", "Item", "Categoria", "Marca", "Valor Unit.", "Qtd. Estoque"}, 0) {
            private final Class<?>[] tipos = {Integer.class, String.class, String.class, String.class, Double.class, Integer.class};

            @Override
            public boolean isCellEditable(int linha, int coluna) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int coluna) {
                return tipos[coluna];
            }
        };
        tblProdutos = new javax.swing.JTable(modeloTabela);
        tblProdutos.setAutoCreateRowSorter(true);
        tblProdutos.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tblProdutos.setDefaultRenderer(Double.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object valor) {
                setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
                setText(valor == null ? "" : String.format("%.2f", (Double) valor));
            }
        });
        tblProdutos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                selecionarLinha();
            }
        });
        jScrollPane1 = new javax.swing.JScrollPane(tblProdutos);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(560, 320));

        javax.swing.JPanel painelCampos = new javax.swing.JPanel(new java.awt.GridBagLayout());
        javax.swing.JPanel linhaCodigo = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
        linhaCodigo.add(txtCodigoProduto);
        linhaCodigo.add(javax.swing.Box.createHorizontalStrut(6));
        linhaCodigo.add(btnBuscar);
        adicionarCampo(painelCampos, 0, "Código", linhaCodigo);
        adicionarCampo(painelCampos, 1, "Nome", txtNomeProduto);
        adicionarCampo(painelCampos, 2, "Categoria", txtCategoriaProduto);
        adicionarCampo(painelCampos, 3, "Marca", txtMarcaProduto);
        adicionarCampo(painelCampos, 4, "Valor", txtValorProduto);
        adicionarCampo(painelCampos, 5, "Quantidade", txtQuantidadeProduto);
        javax.swing.JPanel painelBotoes = new javax.swing.JPanel(new java.awt.GridLayout(2, 4, 6, 6));
        painelBotoes.add(btnNovo);
        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnAlterar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnListar);
        painelBotoes.add(btnLimpar);

        javax.swing.JPanel painelEsquerdo = new javax.swing.JPanel(new java.awt.BorderLayout(0, 12));
        painelEsquerdo.add(jLabel1, java.awt.BorderLayout.NORTH);
        painelEsquerdo.add(painelCampos, java.awt.BorderLayout.CENTER);
        painelEsquerdo.add(painelBotoes, java.awt.BorderLayout.SOUTH);

        javax.swing.JPanel conteudo = new javax.swing.JPanel(new java.awt.BorderLayout(15, 0));
        conteudo.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 12, 12, 12));
        conteudo.add(painelEsquerdo, java.awt.BorderLayout.WEST);
        conteudo.add(jScrollPane1, java.awt.BorderLayout.CENTER);
        setContentPane(conteudo);

        pack();
        setLocationRelativeTo(null);
    }

    private void adicionarCampo(javax.swing.JPanel painel, int linha, String rotulo, java.awt.Component campo) {
        java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints();
        gbc.gridy = linha;
        gbc.insets = new java.awt.Insets(4, 4, 4, 4);
        gbc.anchor = java.awt.GridBagConstraints.WEST;
        gbc.gridx = 0;
        painel.add(new javax.swing.JLabel(rotulo), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        gbc.fill = java.awt.GridBagConstraints.HORIZONTAL;
        painel.add(campo, gbc);
    }

    // ---------- leitura e validacao dos campos da tela ----------

    private int lerCodigo() {
        try {
            return Integer.parseInt(txtCodigoProduto.getText().trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Informe um código numérico válido.");
        }
    }

    private double lerValor(String texto) {
        try {
            return new BigDecimal(texto.trim().replace(',', '.')).doubleValue();
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Informe um valor numérico válido (ex.: 19.90).");
        }
    }

    private int lerInteiro(String texto, String campo) {
        try {
            return Integer.parseInt(texto.trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Informe um número inteiro válido em " + campo + ".");
        }
    }

    private String textoOuNulo(String texto) {
        return texto.trim().isEmpty() ? null : texto.trim();
    }

    private void lerCampos() {
        objProd.setNomeProduto(txtNomeProduto.getText());
        objProd.setCategoriaProduto(textoOuNulo(txtCategoriaProduto.getText()));
        objProd.setMarcaProduto(textoOuNulo(txtMarcaProduto.getText()));
        objProd.setValorProduto(lerValor(txtValorProduto.getText()));
        objProd.setQuantidadeProduto(lerInteiro(txtQuantidadeProduto.getText(), "Quantidade"));
    }

    private void mostrarCampos() {
        txtCodigoProduto.setText(String.valueOf(objProd.getCodigoProduto()));
        txtNomeProduto.setText(objProd.getNomeProduto() == null ? "" : objProd.getNomeProduto());
        txtCategoriaProduto.setText(objProd.getCategoriaProduto() == null ? "" : objProd.getCategoriaProduto());
        txtMarcaProduto.setText(objProd.getMarcaProduto() == null ? "" : objProd.getMarcaProduto());
        txtValorProduto.setText(BigDecimal.valueOf(objProd.getValorProduto()).setScale(2, RoundingMode.HALF_UP).toPlainString());
        txtQuantidadeProduto.setText(String.valueOf(objProd.getQuantidadeProduto()));
    }

    // ---------- eventos ----------

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            lerCampos();

            int novoCodigo = objConProd.Cadastrar(objProd);
            JOptionPane.showMessageDialog(this, "Produto cadastrado com sucesso! Código: " + novoCodigo);
            inicio();
            listar();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            carregar(lerCodigo());
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {
        inicio();
        btnNovo.setEnabled(false);
        txtNomeProduto.setEnabled(true);
        txtCategoriaProduto.setEnabled(true);
        txtMarcaProduto.setEnabled(true);
        txtValorProduto.setEnabled(true);
        txtQuantidadeProduto.setEnabled(true);
        txtCodigoProduto.setEnabled(false);
        btnBuscar.setEnabled(false);
        btnSalvar.setEnabled(true);
    }

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            lerCampos();
            objProd.setCodigoProduto(lerCodigo());

            if (objConProd.Alterar(objProd)) {
                JOptionPane.showMessageDialog(this, "Produto alterado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Produto não encontrado; nada foi alterado.");
            }
            inicio();
            listar();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int codigo = lerCodigo();
            int opcao = JOptionPane.showConfirmDialog(this,
                    "Excluir o registro de código " + codigo + "?",
                    "Confirmar exclusão", JOptionPane.YES_NO_OPTION);
            if (opcao != JOptionPane.YES_OPTION) {
                return;
            }

            if (objConProd.Excluir(codigo)) {
                JOptionPane.showMessageDialog(this, "Produto excluído com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Produto não encontrado; nada foi excluído.");
            }
            inicio();
            listar();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void btnListarActionPerformed(java.awt.event.ActionEvent evt) {
        listar();
    }

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {
        inicio();
    }

    // ---------- apoio da interface ----------

    /** Busca pelo codigo e preenche os campos; se nao existir, avisa e limpa. */
    private void carregar(int codigo) {
        try {
            Produto encontrado = objConProd.BuscarId(codigo);
            if (encontrado == null) {
                JOptionPane.showMessageDialog(this, "Produto não encontrado.");
                inicio();
                return;
            }
            objProd = encontrado;
            mostrarCampos();

            btnNovo.setEnabled(false);
            btnSalvar.setEnabled(false);
            btnAlterar.setEnabled(true);
            btnExcluir.setEnabled(true);
        txtNomeProduto.setEnabled(true);
        txtCategoriaProduto.setEnabled(true);
        txtMarcaProduto.setEnabled(true);
        txtValorProduto.setEnabled(true);
        txtQuantidadeProduto.setEnabled(true);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void selecionarLinha() {
        int linha = tblProdutos.getSelectedRow();
        if (linha < 0) {
            return;
        }
        int linhaModelo = tblProdutos.convertRowIndexToModel(linha);
        carregar((Integer) modeloTabela.getValueAt(linhaModelo, 0));
    }

    /** Estado inicial: campos desabilitados e campos limpos. */
    private void inicio(){
        tblProdutos.clearSelection();
        btnSalvar.setEnabled(false);
        btnAlterar.setEnabled(false);
        btnExcluir.setEnabled(false);
        txtNomeProduto.setEnabled(false);
        txtCategoriaProduto.setEnabled(false);
        txtMarcaProduto.setEnabled(false);
        txtValorProduto.setEnabled(false);
        txtQuantidadeProduto.setEnabled(false);
        btnNovo.setEnabled(true);
        txtCodigoProduto.setText("");
        txtNomeProduto.setText("");
        txtCategoriaProduto.setText("");
        txtMarcaProduto.setText("");
        txtValorProduto.setText("");
        txtQuantidadeProduto.setText("");
        txtCodigoProduto.setEnabled(true);
        btnBuscar.setEnabled(true);
    }

    /** Recarrega a JTable: setRowCount(0) evita linhas duplicadas. */
    private void listar(){
        try {
            List<Produto> lista = objConProd.Listar();
            modeloTabela.setRowCount(0);
            for (Produto item : lista) {
                modeloTabela.addRow(new Object[]{
                    item.getCodigoProduto(),
                    item.getNomeProduto(),
                    item.getCategoriaProduto(),
                    item.getMarcaProduto(),
                    item.getValorProduto(),
                    item.getQuantidadeProduto()
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new frmProduto().setVisible(true));
    }

    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnListar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblProdutos;
    private javax.swing.JTextField txtCodigoProduto;
    private javax.swing.JTextField txtCategoriaProduto;
    private javax.swing.JTextField txtMarcaProduto;
    private javax.swing.JTextField txtNomeProduto;
    private javax.swing.JTextField txtQuantidadeProduto;
    private javax.swing.JTextField txtValorProduto;
}
