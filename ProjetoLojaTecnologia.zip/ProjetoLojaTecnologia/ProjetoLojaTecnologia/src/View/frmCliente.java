/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Controller.conCliente;
import Model.Cliente;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author LABINFO
 */
public class frmCliente extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(frmCliente.class.getName());

    /**
     * Creates new form frmCliente
     */
    public frmCliente() {
        initComponents();
        inicio();
        listar();
    }
    Cliente objCli = new Cliente();
    conCliente objConCli = new conCliente();
    private DefaultTableModel modeloTabela;

    /**
     * Monta a tela. Ao contrario das telas criadas no modo Design, este
     * codigo foi escrito a mao: edite-o diretamente no modo Source.
     */
    private void initComponents() {

        setTitle("Cadastro de Clientes");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1 = new javax.swing.JLabel("Cadastro de Clientes");
        jLabel1.setFont(jLabel1.getFont().deriveFont(java.awt.Font.BOLD, 18f));

        txtCodigoCliente = new javax.swing.JTextField(8);
        txtNomeCliente = new javax.swing.JTextField(24);
        txtCpfCliente = new javax.swing.JTextField(14);
        txtTelefoneCliente = new javax.swing.JTextField(14);
        txtEmailCliente = new javax.swing.JTextField(24);
        txtEnderecoCliente = new javax.swing.JTextField(24);
        btnBuscar = new javax.swing.JButton("BUSCAR");
        btnNovo = new javax.swing.JButton("NOVO");
        btnSalvar = new javax.swing.JButton("SALVAR");
        btnAlterar = new javax.swing.JButton("ALTERAR");
        btnExcluir = new javax.swing.JButton("EXCLUIR");
        btnListar = new javax.swing.JButton("LISTAR");
        btnLimpar = new javax.swing.JButton("LIMPAR");

        txtCodigoCliente.addActionListener(this::btnBuscarActionPerformed);
        btnBuscar.addActionListener(this::btnBuscarActionPerformed);
        btnNovo.addActionListener(this::btnNovoActionPerformed);
        btnSalvar.addActionListener(this::btnSalvarActionPerformed);
        btnAlterar.addActionListener(this::btnAlterarActionPerformed);
        btnExcluir.addActionListener(this::btnExcluirActionPerformed);
        btnListar.addActionListener(this::btnListarActionPerformed);
        btnLimpar.addActionListener(this::btnLimparActionPerformed);

        modeloTabela = new DefaultTableModel(new Object[]{"Cód. Cliente", "Nome", "CPF", "Telefone", "E-mail", "Endereço"}, 0) {
            private final Class<?>[] tipos = {Integer.class, String.class, String.class, String.class, String.class, String.class};

            @Override
            public boolean isCellEditable(int linha, int coluna) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int coluna) {
                return tipos[coluna];
            }
        };
        tblClientes = new javax.swing.JTable(modeloTabela);
        tblClientes.setAutoCreateRowSorter(true);
        tblClientes.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tblClientes.setDefaultRenderer(Double.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object valor) {
                setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
                setText(valor == null ? "" : String.format("%.2f", (Double) valor));
            }
        });
        tblClientes.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                selecionarLinha();
            }
        });
        jScrollPane1 = new javax.swing.JScrollPane(tblClientes);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(560, 320));

        javax.swing.JPanel painelCampos = new javax.swing.JPanel(new java.awt.GridBagLayout());
        javax.swing.JPanel linhaCodigo = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
        linhaCodigo.add(txtCodigoCliente);
        linhaCodigo.add(javax.swing.Box.createHorizontalStrut(6));
        linhaCodigo.add(btnBuscar);
        adicionarCampo(painelCampos, 0, "Código", linhaCodigo);
        adicionarCampo(painelCampos, 1, "Nome", txtNomeCliente);
        adicionarCampo(painelCampos, 2, "CPF", txtCpfCliente);
        adicionarCampo(painelCampos, 3, "Telefone", txtTelefoneCliente);
        adicionarCampo(painelCampos, 4, "E-mail", txtEmailCliente);
        adicionarCampo(painelCampos, 5, "Endereço", txtEnderecoCliente);
        javax.swing.JPanel painelBotoes = new javax.swing.JPanel(new java.awt.GridLayout(2, 4, 6, 6));
        painelBotoes.add(btnNovo);
        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnAlterar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnListar);
        painelBotoes.add(btnLimpar);

        javax.swing.JPanel painelEsquerdo = new javax.swing.JPanel(new java.awt.BorderLayout(0, 12));
        painelEsquerdo.add(jLabel1, java.awt.BorderLayout.NORTH);
        painelEsquerdo.add(painelCampos, java.awt.BorderLayout.CENTER);
        painelEsquerdo.add(painelBotoes, java.awt.BorderLayout.SOUTH);

        javax.swing.JPanel conteudo = new javax.swing.JPanel(new java.awt.BorderLayout(15, 0));
        conteudo.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 12, 12, 12));
        conteudo.add(painelEsquerdo, java.awt.BorderLayout.WEST);
        conteudo.add(jScrollPane1, java.awt.BorderLayout.CENTER);
        setContentPane(conteudo);

        pack();
        setLocationRelativeTo(null);
    }

    private void adicionarCampo(javax.swing.JPanel painel, int linha, String rotulo, java.awt.Component campo) {
        java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints();
        gbc.gridy = linha;
        gbc.insets = new java.awt.Insets(4, 4, 4, 4);
        gbc.anchor = java.awt.GridBagConstraints.WEST;
        gbc.gridx = 0;
        painel.add(new javax.swing.JLabel(rotulo), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        gbc.fill = java.awt.GridBagConstraints.HORIZONTAL;
        painel.add(campo, gbc);
    }

    // ---------- leitura e validacao dos campos da tela ----------

    private int lerCodigo() {
        try {
            return Integer.parseInt(txtCodigoCliente.getText().trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Informe um código numérico válido.");
        }
    }

    private String textoOuNulo(String texto) {
        return texto.trim().isEmpty() ? null : texto.trim();
    }

    private void lerCampos() {
        objCli.setNomeCliente(txtNomeCliente.getText());
        objCli.setCpfCliente(txtCpfCliente.getText());
        objCli.setTelefoneCliente(textoOuNulo(txtTelefoneCliente.getText()));
        objCli.setEmailCliente(textoOuNulo(txtEmailCliente.getText()));
        objCli.setEnderecoCliente(textoOuNulo(txtEnderecoCliente.getText()));
    }

    private void mostrarCampos() {
        txtCodigoCliente.setText(String.valueOf(objCli.getCodigoCliente()));
        txtNomeCliente.setText(objCli.getNomeCliente() == null ? "" : objCli.getNomeCliente());
        txtCpfCliente.setText(objCli.getCpfCliente() == null ? "" : objCli.getCpfCliente());
        txtTelefoneCliente.setText(objCli.getTelefoneCliente() == null ? "" : objCli.getTelefoneCliente());
        txtEmailCliente.setText(objCli.getEmailCliente() == null ? "" : objCli.getEmailCliente());
        txtEnderecoCliente.setText(objCli.getEnderecoCliente() == null ? "" : objCli.getEnderecoCliente());
    }

    // ---------- eventos ----------

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            lerCampos();

            int novoCodigo = objConCli.Cadastrar(objCli);
            JOptionPane.showMessageDialog(this, "Cliente cadastrado com sucesso! Código: " + novoCodigo);
            inicio();
            listar();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            carregar(lerCodigo());
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {
        inicio();
        btnNovo.setEnabled(false);
        txtNomeCliente.setEnabled(true);
        txtCpfCliente.setEnabled(true);
        txtTelefoneCliente.setEnabled(true);
        txtEmailCliente.setEnabled(true);
        txtEnderecoCliente.setEnabled(true);
        txtCodigoCliente.setEnabled(false);
        btnBuscar.setEnabled(false);
        btnSalvar.setEnabled(true);
    }

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            lerCampos();
            objCli.setCodigoCliente(lerCodigo());

            if (objConCli.Alterar(objCli)) {
                JOptionPane.showMessageDialog(this, "Cliente alterado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Cliente não encontrado; nada foi alterado.");
            }
            inicio();
            listar();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int codigo = lerCodigo();
            int opcao = JOptionPane.showConfirmDialog(this,
                    "Excluir o registro de código " + codigo + "?",
                    "Confirmar exclusão", JOptionPane.YES_NO_OPTION);
            if (opcao != JOptionPane.YES_OPTION) {
                return;
            }

            if (objConCli.Excluir(codigo)) {
                JOptionPane.showMessageDialog(this, "Cliente excluído com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Cliente não encontrado; nada foi excluído.");
            }
            inicio();
            listar();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void btnListarActionPerformed(java.awt.event.ActionEvent evt) {
        listar();
    }

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {
        inicio();
    }

    // ---------- apoio da interface ----------

    /** Busca pelo codigo e preenche os campos; se nao existir, avisa e limpa. */
    private void carregar(int codigo) {
        try {
            Cliente encontrado = objConCli.BuscarId(codigo);
            if (encontrado == null) {
                JOptionPane.showMessageDialog(this, "Cliente não encontrado.");
                inicio();
                return;
            }
            objCli = encontrado;
            mostrarCampos();

            btnNovo.setEnabled(false);
            btnSalvar.setEnabled(false);
            btnAlterar.setEnabled(true);
            btnExcluir.setEnabled(true);
        txtNomeCliente.setEnabled(true);
        txtCpfCliente.setEnabled(true);
        txtTelefoneCliente.setEnabled(true);
        txtEmailCliente.setEnabled(true);
        txtEnderecoCliente.setEnabled(true);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void selecionarLinha() {
        int linha = tblClientes.getSelectedRow();
        if (linha < 0) {
            return;
        }
        int linhaModelo = tblClientes.convertRowIndexToModel(linha);
        carregar((Integer) modeloTabela.getValueAt(linhaModelo, 0));
    }

    /** Estado inicial: campos desabilitados e campos limpos. */
    private void inicio(){
        tblClientes.clearSelection();
        btnSalvar.setEnabled(false);
        btnAlterar.setEnabled(false);
        btnExcluir.setEnabled(false);
        txtNomeCliente.setEnabled(false);
        txtCpfCliente.setEnabled(false);
        txtTelefoneCliente.setEnabled(false);
        txtEmailCliente.setEnabled(false);
        txtEnderecoCliente.setEnabled(false);
        btnNovo.setEnabled(true);
        txtCodigoCliente.setText("");
        txtNomeCliente.setText("");
        txtCpfCliente.setText("");
        txtTelefoneCliente.setText("");
        txtEmailCliente.setText("");
        txtEnderecoCliente.setText("");
        txtCodigoCliente.setEnabled(true);
        btnBuscar.setEnabled(true);
    }

    /** Recarrega a JTable: setRowCount(0) evita linhas duplicadas. */
    private void listar(){
        try {
            List<Cliente> lista = objConCli.Listar();
            modeloTabela.setRowCount(0);
            for (Cliente item : lista) {
                modeloTabela.addRow(new Object[]{
                    item.getCodigoCliente(),
                    item.getNomeCliente(),
                    item.getCpfCliente(),
                    item.getTelefoneCliente(),
                    item.getEmailCliente(),
                    item.getEnderecoCliente()
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new frmCliente().setVisible(true));
    }

    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnListar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblClientes;
    private javax.swing.JTextField txtCodigoCliente;
    private javax.swing.JTextField txtCpfCliente;
    private javax.swing.JTextField txtEmailCliente;
    private javax.swing.JTextField txtEnderecoCliente;
    private javax.swing.JTextField txtNomeCliente;
    private javax.swing.JTextField txtTelefoneCliente;
}
