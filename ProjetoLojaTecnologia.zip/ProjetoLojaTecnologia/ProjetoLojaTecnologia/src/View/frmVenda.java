/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Controller.conCliente;
import Controller.conProduto;
import Controller.conVenda;
import Model.Cliente;
import Model.ItemVenda;
import Model.Produto;
import Model.Venda;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * Venda (TBVENDA) com seus itens (TBITEMVENDA), cliente (TBCLIENTE) e
 * produtos (TBPRODUTO). SALVAR registra uma venda nova com todos os itens;
 * ALTERAR muda somente forma de pagamento e status de uma venda existente.
 *
 * @author LABINFO
 */
public class frmVenda extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(frmVenda.class.getName());

    /** Item de combo: guarda o codigo do registro e o texto exibido. */
    private static class Opcao {
        final int codigo;
        final String texto;

        Opcao(int codigo, String texto) {
            this.codigo = codigo;
            this.texto = texto;
        }

        @Override
        public String toString() {
            return texto;
        }
    }

    /**
     * Creates new form frmVenda
     */
    public frmVenda() {
        initComponents();
        carregarCombos();
        inicio();
        listar();
    }
    Venda objVenda = new Venda();
    conVenda objConVenda = new conVenda();
    conCliente objConCli = new conCliente();
    conProduto objConProd = new conProduto();
    private List<ItemVenda> itensVenda = new ArrayList<>();
    private List<Produto> produtos = new ArrayList<>();
    private DefaultTableModel modeloVendas;
    private DefaultTableModel modeloItens;
    private final SimpleDateFormat formatoData = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    /**
     * Monta a tela. Ao contrario das telas criadas no modo Design, este
     * codigo foi escrito a mao: edite-o diretamente no modo Source.
     */
    private void initComponents() {

        setTitle("Registro de Vendas");
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1 = new javax.swing.JLabel("Registro de Vendas");
        jLabel1.setFont(jLabel1.getFont().deriveFont(java.awt.Font.BOLD, 18f));

        txtCodigoVenda = new javax.swing.JTextField(8);
        txtQuantidadeItem = new javax.swing.JTextField(5);
        cmbCliente = new javax.swing.JComboBox<>();
        cmbFormaPagamento = new javax.swing.JComboBox<>(conVenda.FORMAS_PAGAMENTO);
        cmbStatusVenda = new javax.swing.JComboBox<>(conVenda.STATUS_VENDA);
        cmbProduto = new javax.swing.JComboBox<>();
        lblTotal = new javax.swing.JLabel("Total: R$ 0,00");
        lblTotal.setFont(lblTotal.getFont().deriveFont(java.awt.Font.BOLD, 14f));

        btnBuscar = new javax.swing.JButton("BUSCAR");
        btnAdicionarItem = new javax.swing.JButton("ADICIONAR");
        btnRemoverItem = new javax.swing.JButton("REMOVER");
        btnNovo = new javax.swing.JButton("NOVO");
        btnSalvar = new javax.swing.JButton("SALVAR");
        btnAlterar = new javax.swing.JButton("ALTERAR");
        btnExcluir = new javax.swing.JButton("EXCLUIR");
        btnListar = new javax.swing.JButton("LISTAR");
        btnLimpar = new javax.swing.JButton("LIMPAR");

        txtCodigoVenda.addActionListener(this::btnBuscarActionPerformed);
        btnBuscar.addActionListener(this::btnBuscarActionPerformed);
        btnAdicionarItem.addActionListener(this::btnAdicionarItemActionPerformed);
        btnRemoverItem.addActionListener(this::btnRemoverItemActionPerformed);
        btnNovo.addActionListener(this::btnNovoActionPerformed);
        btnSalvar.addActionListener(this::btnSalvarActionPerformed);
        btnAlterar.addActionListener(this::btnAlterarActionPerformed);
        btnExcluir.addActionListener(this::btnExcluirActionPerformed);
        btnListar.addActionListener(this::btnListarActionPerformed);
        btnLimpar.addActionListener(this::btnLimparActionPerformed);

        modeloItens = criarModelo(new String[]{"Cód. Prod.", "Produto", "Qtd.", "Valor Unit.", "Subtotal"},
                new Class<?>[]{Integer.class, String.class, Integer.class, Double.class, Double.class});
        tblItens = new javax.swing.JTable(modeloItens);
        configurarTabela(tblItens);
        jScrollPane2 = new javax.swing.JScrollPane(tblItens);
        jScrollPane2.setPreferredSize(new java.awt.Dimension(420, 150));

        modeloVendas = criarModelo(new String[]{"Cód. Venda", "Cliente", "Data", "Pagamento", "Status", "Valor Total"},
                new Class<?>[]{Integer.class, String.class, java.util.Date.class, String.class, String.class, Double.class});
        tblVendas = new javax.swing.JTable(modeloVendas);
        configurarTabela(tblVendas);
        tblVendas.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                selecionarLinha();
            }
        });
        jScrollPane1 = new javax.swing.JScrollPane(tblVendas);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(560, 420));

        javax.swing.JPanel painelCampos = new javax.swing.JPanel(new java.awt.GridBagLayout());
        javax.swing.JPanel linhaCodigo = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
        linhaCodigo.add(txtCodigoVenda);
        linhaCodigo.add(javax.swing.Box.createHorizontalStrut(6));
        linhaCodigo.add(btnBuscar);
        adicionarCampo(painelCampos, 0, "Código", linhaCodigo);
        adicionarCampo(painelCampos, 1, "Cliente", cmbCliente);
        adicionarCampo(painelCampos, 2, "Pagamento", cmbFormaPagamento);
        adicionarCampo(painelCampos, 3, "Status", cmbStatusVenda);
        adicionarCampo(painelCampos, 4, "Produto", cmbProduto);
        javax.swing.JPanel linhaItem = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
        linhaItem.add(txtQuantidadeItem);
        linhaItem.add(javax.swing.Box.createHorizontalStrut(6));
        linhaItem.add(btnAdicionarItem);
        linhaItem.add(javax.swing.Box.createHorizontalStrut(6));
        linhaItem.add(btnRemoverItem);
        adicionarCampo(painelCampos, 5, "Quantidade", linhaItem);

        javax.swing.JPanel painelItens = new javax.swing.JPanel(new java.awt.BorderLayout(0, 4));
        painelItens.add(jScrollPane2, java.awt.BorderLayout.CENTER);
        painelItens.add(lblTotal, java.awt.BorderLayout.SOUTH);

        javax.swing.JPanel painelMeio = new javax.swing.JPanel(new java.awt.BorderLayout(0, 8));
        painelMeio.add(painelCampos, java.awt.BorderLayout.NORTH);
        painelMeio.add(painelItens, java.awt.BorderLayout.CENTER);

        javax.swing.JPanel painelBotoes = new javax.swing.JPanel(new java.awt.GridLayout(2, 3, 6, 6));
        painelBotoes.add(btnNovo);
        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnAlterar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnListar);
        painelBotoes.add(btnLimpar);

        javax.swing.JPanel painelEsquerdo = new javax.swing.JPanel(new java.awt.BorderLayout(0, 12));
        painelEsquerdo.add(jLabel1, java.awt.BorderLayout.NORTH);
        painelEsquerdo.add(painelMeio, java.awt.BorderLayout.CENTER);
        painelEsquerdo.add(painelBotoes, java.awt.BorderLayout.SOUTH);

        javax.swing.JPanel conteudo = new javax.swing.JPanel(new java.awt.BorderLayout(15, 0));
        conteudo.setBorder(javax.swing.BorderFactory.createEmptyBorder(12, 12, 12, 12));
        conteudo.add(painelEsquerdo, java.awt.BorderLayout.WEST);
        conteudo.add(jScrollPane1, java.awt.BorderLayout.CENTER);
        setContentPane(conteudo);

        pack();
        setLocationRelativeTo(null);
    }

    private void adicionarCampo(javax.swing.JPanel painel, int linha, String rotulo, java.awt.Component campo) {
        java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints();
        gbc.gridy = linha;
        gbc.insets = new java.awt.Insets(4, 4, 4, 4);
        gbc.anchor = java.awt.GridBagConstraints.WEST;
        gbc.gridx = 0;
        painel.add(new javax.swing.JLabel(rotulo), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        gbc.fill = java.awt.GridBagConstraints.HORIZONTAL;
        painel.add(campo, gbc);
    }

    /** Modelo somente leitura que informa o tipo de cada coluna (ordenacao correta). */
    private DefaultTableModel criarModelo(String[] cabecalho, Class<?>[] tipos) {
        return new DefaultTableModel(cabecalho, 0) {
            @Override
            public boolean isCellEditable(int linha, int coluna) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int coluna) {
                return tipos[coluna];
            }
        };
    }

    private void configurarTabela(javax.swing.JTable tabela) {
        tabela.setAutoCreateRowSorter(true);
        tabela.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tabela.setDefaultRenderer(Double.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object valor) {
                setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
                setText(valor == null ? "" : String.format("%.2f", (Double) valor));
            }
        });
        tabela.setDefaultRenderer(java.util.Date.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object valor) {
                setText(valor == null ? "" : formatoData.format((java.util.Date) valor));
            }
        });
    }

    // ---------- leitura e validacao dos campos da tela ----------

    private int lerInteiro(String texto, String campo) {
        try {
            return Integer.parseInt(texto.trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Informe um número inteiro válido em " + campo + ".");
        }
    }

    private Produto produtoPorCodigo(int codigo) {
        for (Produto prod : produtos) {
            if (prod.getCodigoProduto() == codigo) {
                return prod;
            }
        }
        return null;
    }

    private void selecionarOpcao(javax.swing.JComboBox<Opcao> combo, int codigo) {
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (combo.getItemAt(i).codigo == codigo) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }

    // ---------- eventos ----------

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {
        inicio();
        btnNovo.setEnabled(false);
        cmbCliente.setEnabled(true);
        cmbFormaPagamento.setEnabled(true);
        cmbStatusVenda.setEnabled(true);
        cmbProduto.setEnabled(true);
        txtQuantidadeItem.setEnabled(true);
        btnAdicionarItem.setEnabled(true);
        btnRemoverItem.setEnabled(true);
        txtCodigoVenda.setEnabled(false);
        btnBuscar.setEnabled(false);
        btnSalvar.setEnabled(true);
    }

    private void btnAdicionarItemActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            Opcao opcao = (Opcao) cmbProduto.getSelectedItem();
            if (opcao == null) {
                throw new IllegalArgumentException("Escolha um produto.");
            }
            int quantidade = lerInteiro(txtQuantidadeItem.getText(), "Quantidade");
            if (quantidade <= 0) {
                throw new IllegalArgumentException("A quantidade deve ser maior que zero.");
            }
            Produto prod = produtoPorCodigo(opcao.codigo);

            ItemVenda existente = null;
            for (ItemVenda item : itensVenda) {
                if (item.getCodigoProduto() == prod.getCodigoProduto()) {
                    existente = item;
                }
            }
            int jaAdicionado = existente == null ? 0 : existente.getQuantidadeItem();
            if (jaAdicionado + quantidade > prod.getQuantidadeProduto()) {
                throw new IllegalArgumentException("Estoque insuficiente de " + prod.getNomeProduto()
                        + " (disponível: " + prod.getQuantidadeProduto() + ").");
            }

            if (existente == null) {
                ItemVenda novo = new ItemVenda();
                novo.setCodigoProduto(prod.getCodigoProduto());
                novo.setNomeProduto(prod.getNomeProduto());
                novo.setQuantidadeItem(quantidade);
                novo.setValorUnitario(prod.getValorProduto());
                itensVenda.add(novo);
            } else {
                existente.setQuantidadeItem(jaAdicionado + quantidade);
            }
            txtQuantidadeItem.setText("");
            mostrarItens();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void btnRemoverItemActionPerformed(java.awt.event.ActionEvent evt) {
        int linha = tblItens.getSelectedRow();
        if (linha < 0) {
            JOptionPane.showMessageDialog(this, "Selecione o item que deseja remover.");
            return;
        }
        itensVenda.remove(tblItens.convertRowIndexToModel(linha));
        mostrarItens();
    }

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            Opcao cliente = (Opcao) cmbCliente.getSelectedItem();
            if (cliente == null) {
                throw new IllegalArgumentException("Escolha o cliente da venda.");
            }
            objVenda = new Venda();
            objVenda.setCodigoCliente(cliente.codigo);
            objVenda.setFormaPagamento((String) cmbFormaPagamento.getSelectedItem());
            objVenda.setStatusVenda((String) cmbStatusVenda.getSelectedItem());

            int novoCodigo = objConVenda.Cadastrar(objVenda, itensVenda);
            JOptionPane.showMessageDialog(this, "Venda registrada com sucesso! Código: " + novoCodigo);
            carregarCombos();
            inicio();
            listar();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            carregar(lerInteiro(txtCodigoVenda.getText(), "Código"));
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            objVenda.setCodigoVenda(lerInteiro(txtCodigoVenda.getText(), "Código"));
            objVenda.setFormaPagamento((String) cmbFormaPagamento.getSelectedItem());
            objVenda.setStatusVenda((String) cmbStatusVenda.getSelectedItem());

            if (objConVenda.Alterar(objVenda)) {
                JOptionPane.showMessageDialog(this, "Venda alterada com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Venda não encontrada; nada foi alterado.");
            }
            inicio();
            listar();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            int codigo = lerInteiro(txtCodigoVenda.getText(), "Código");
            int opcao = JOptionPane.showConfirmDialog(this,
                    "Excluir a venda " + codigo + " e devolver os itens ao estoque?",
                    "Confirmar exclusão", JOptionPane.YES_NO_OPTION);
            if (opcao != JOptionPane.YES_OPTION) {
                return;
            }

            if (objConVenda.Excluir(codigo)) {
                JOptionPane.showMessageDialog(this, "Venda excluída com sucesso!");
            } else {
                JOptionPane.showMessageDialog(this, "Venda não encontrada; nada foi excluído.");
            }
            carregarCombos();
            inicio();
            listar();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void btnListarActionPerformed(java.awt.event.ActionEvent evt) {
        carregarCombos();
        listar();
    }

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {
        inicio();
    }

    // ---------- apoio da interface ----------

    /** Preenche os combos de cliente (TBCLIENTE) e produto (TBPRODUTO). */
    private void carregarCombos() {
        try {
            cmbCliente.removeAllItems();
            for (Cliente cli : objConCli.Listar()) {
                cmbCliente.addItem(new Opcao(cli.getCodigoCliente(),
                        cli.getCodigoCliente() + " - " + cli.getNomeCliente()));
            }
            produtos = objConProd.Listar();
            cmbProduto.removeAllItems();
            for (Produto prod : produtos) {
                cmbProduto.addItem(new Opcao(prod.getCodigoProduto(),
                        prod.getNomeProduto() + " (R$ " + String.format("%.2f", prod.getValorProduto())
                        + ", estoque " + prod.getQuantidadeProduto() + ")"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    /** Busca a venda pelo codigo, preenche os campos e mostra os itens gravados. */
    private void carregar(int codigo) {
        try {
            Venda encontrada = objConVenda.BuscarId(codigo);
            if (encontrada == null) {
                JOptionPane.showMessageDialog(this, "Venda não encontrada.");
                inicio();
                return;
            }
            objVenda = encontrada;
            txtCodigoVenda.setText(String.valueOf(objVenda.getCodigoVenda()));
            selecionarOpcao(cmbCliente, objVenda.getCodigoCliente());
            cmbFormaPagamento.setSelectedItem(objVenda.getFormaPagamento());
            cmbStatusVenda.setSelectedItem(objVenda.getStatusVenda());
            itensVenda = objConVenda.ListarItens(codigo);
            mostrarItens();

            btnNovo.setEnabled(false);
            btnSalvar.setEnabled(false);
            btnAlterar.setEnabled(true);
            btnExcluir.setEnabled(true);
            cmbFormaPagamento.setEnabled(true);
            cmbStatusVenda.setEnabled(true);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    private void selecionarLinha() {
        int linha = tblVendas.getSelectedRow();
        if (linha < 0) {
            return;
        }
        int linhaModelo = tblVendas.convertRowIndexToModel(linha);
        carregar((Integer) modeloVendas.getValueAt(linhaModelo, 0));
    }

    /** Mostra os itens da venda em edicao (ou da venda carregada) e o total. */
    private void mostrarItens() {
        modeloItens.setRowCount(0);
        BigDecimal total = BigDecimal.ZERO;
        for (ItemVenda item : itensVenda) {
            BigDecimal subtotal = BigDecimal.valueOf(item.getValorUnitario())
                    .multiply(BigDecimal.valueOf(item.getQuantidadeItem()));
            total = total.add(subtotal);
            modeloItens.addRow(new Object[]{
                item.getCodigoProduto(),
                item.getNomeProduto(),
                item.getQuantidadeItem(),
                item.getValorUnitario(),
                subtotal.doubleValue()
            });
        }
        lblTotal.setText("Total: R$ " + String.format("%.2f", total));
    }

    /** Estado inicial: campos desabilitados e campos limpos. */
    private void inicio(){
        tblVendas.clearSelection();
        btnSalvar.setEnabled(false);
        btnAlterar.setEnabled(false);
        btnExcluir.setEnabled(false);
        cmbCliente.setEnabled(false);
        cmbFormaPagamento.setEnabled(false);
        cmbStatusVenda.setEnabled(false);
        cmbProduto.setEnabled(false);
        txtQuantidadeItem.setEnabled(false);
        btnAdicionarItem.setEnabled(false);
        btnRemoverItem.setEnabled(false);
        btnNovo.setEnabled(true);
        txtCodigoVenda.setText("");
        txtQuantidadeItem.setText("");
        if (cmbCliente.getItemCount() > 0) {
            cmbCliente.setSelectedIndex(0);
        }
        if (cmbProduto.getItemCount() > 0) {
            cmbProduto.setSelectedIndex(0);
        }
        cmbFormaPagamento.setSelectedIndex(0);
        cmbStatusVenda.setSelectedIndex(0);
        itensVenda = new ArrayList<>();
        mostrarItens();
        txtCodigoVenda.setEnabled(true);
        btnBuscar.setEnabled(true);
    }

    /** Recarrega a JTable de vendas: setRowCount(0) evita linhas duplicadas. */
    private void listar(){
        try {
            List<Venda> lista = objConVenda.Listar();
            modeloVendas.setRowCount(0);
            for (Venda item : lista) {
                modeloVendas.addRow(new Object[]{
                    item.getCodigoVenda(),
                    item.getNomeCliente(),
                    item.getDataVenda(),
                    item.getFormaPagamento(),
                    item.getStatusVenda(),
                    item.getValorVenda()
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro: " + ex.getMessage());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new frmVenda().setVisible(true));
    }

    private javax.swing.JButton btnAdicionarItem;
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnListar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnRemoverItem;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox<Opcao> cmbCliente;
    private javax.swing.JComboBox<String> cmbFormaPagamento;
    private javax.swing.JComboBox<Opcao> cmbProduto;
    private javax.swing.JComboBox<String> cmbStatusVenda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblItens;
    private javax.swing.JTable tblVendas;
    private javax.swing.JTextField txtCodigoVenda;
    private javax.swing.JTextField txtQuantidadeItem;
}
