/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

/**
 * Menu principal: abre as telas de clientes, produtos e vendas.
 *
 * @author LABINFO
 */
public class frmPrincipal extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(frmPrincipal.class.getName());

    /**
     * Creates new form frmPrincipal
     */
    public frmPrincipal() {
        initComponents();
    }

    /**
     * Monta a tela. Ao contrario das telas criadas no modo Design, este
     * codigo foi escrito a mao: edite-o diretamente no modo Source.
     */
    private void initComponents() {

        setTitle("Loja de Tecnologia");
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1 = new javax.swing.JLabel("Loja de Tecnologia", javax.swing.SwingConstants.CENTER);
        jLabel1.setFont(jLabel1.getFont().deriveFont(java.awt.Font.BOLD, 28f));
        jLabel2 = new javax.swing.JLabel("Use o menu para abrir os cadastros e o registro de vendas.",
                javax.swing.SwingConstants.CENTER);

        menuBar = new javax.swing.JMenuBar();
        menuCadastros = new javax.swing.JMenu("Cadastros");
        menuClientes = new javax.swing.JMenuItem("Clientes");
        menuProdutos = new javax.swing.JMenuItem("Produtos");
        menuVendas = new javax.swing.JMenu("Vendas");
        menuRegistroVendas = new javax.swing.JMenuItem("Registro de Vendas");
        menuSair = new javax.swing.JMenu("Sair");
        menuFechar = new javax.swing.JMenuItem("Fechar o sistema");

        menuClientes.addActionListener(this::menuClientesActionPerformed);
        menuProdutos.addActionListener(this::menuProdutosActionPerformed);
        menuRegistroVendas.addActionListener(this::menuRegistroVendasActionPerformed);
        menuFechar.addActionListener(this::menuFecharActionPerformed);

        menuCadastros.add(menuClientes);
        menuCadastros.add(menuProdutos);
        menuVendas.add(menuRegistroVendas);
        menuSair.add(menuFechar);
        menuBar.add(menuCadastros);
        menuBar.add(menuVendas);
        menuBar.add(menuSair);
        setJMenuBar(menuBar);

        javax.swing.JPanel conteudo = new javax.swing.JPanel(new java.awt.GridLayout(2, 1));
        conteudo.setBorder(javax.swing.BorderFactory.createEmptyBorder(60, 40, 60, 40));
        conteudo.add(jLabel1);
        conteudo.add(jLabel2);
        setContentPane(conteudo);

        setPreferredSize(new java.awt.Dimension(560, 320));
        pack();
        setLocationRelativeTo(null);
    }

    private void menuClientesActionPerformed(java.awt.event.ActionEvent evt) {
        new frmCliente().setVisible(true);
    }

    private void menuProdutosActionPerformed(java.awt.event.ActionEvent evt) {
        new frmProduto().setVisible(true);
    }

    private void menuRegistroVendasActionPerformed(java.awt.event.ActionEvent evt) {
        new frmVenda().setVisible(true);
    }

    private void menuFecharActionPerformed(java.awt.event.ActionEvent evt) {
        dispose();
        System.exit(0);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new frmPrincipal().setVisible(true));
    }

    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenu menuCadastros;
    private javax.swing.JMenuItem menuClientes;
    private javax.swing.JMenuItem menuFechar;
    private javax.swing.JMenuItem menuProdutos;
    private javax.swing.JMenuItem menuRegistroVendas;
    private javax.swing.JMenu menuSair;
    private javax.swing.JMenu menuVendas;
}
