/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TesteConexao;

import Model.Conexao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Teste {
    public static void main(String[] args){
        String[] tabelas = {"TBCLIENTE", "TBPRODUTO", "TBVENDA", "TBITEMVENDA"};
        try (Connection c = Conexao.conectar();
             Statement st = c.createStatement()) {
            System.out.println("Conexao criada com sucesso: " + c.getCatalog());
            for (String tabela : tabelas) {
                try (ResultSet rs = st.executeQuery("select count(*) from " + tabela)) {
                    rs.next();
                    System.out.println(tabela + ": " + rs.getInt(1) + " registro(s)");
                }
            }
        } catch (SQLException e) {
            System.err.println("Falha: " + e.getMessage());
        }
    }
}
