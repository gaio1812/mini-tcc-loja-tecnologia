# ProjetoLojaTecnologia

Projeto NetBeans (Java com Ant + MySQL, MVC) integrado ao banco `BDLOJATECNOLOGIA`
(script em `sql/loja.sql`).

## Como executar
1. No MySQL Workbench, execute `sql/loja.sql` (cria o banco, as 4 tabelas e os dados de exemplo).
2. Em `src/Model/Conexao.java`, ajuste `usuario` e `senha` do seu MySQL.
3. Abra a pasta no NetBeans, faca *Clean and Build* (o JAR `mysql-connector-j-26.7.0.jar` ja esta em Libraries).
4. Execute `src/TesteConexao/Teste.java` (Run File): deve mostrar a conexao e a contagem de cada tabela.
5. Execute o projeto (main class `View.frmPrincipal`) e use o menu: Cadastros > Clientes / Produtos e Vendas > Registro de Vendas.

## Estrutura
| Pacote | Arquivo | Tabela |
|---|---|---|
| Model | Conexao, Cliente, Produto, Venda, ItemVenda | TBCLIENTE, TBPRODUTO, TBVENDA, TBITEMVENDA |
| Controller | conCliente, conProduto, conVenda | Cadastrar, Alterar, Excluir, BuscarId, Listar (+ ListarItens em conVenda) |
| View | frmPrincipal, frmCliente, frmProduto, frmVenda | |
| TesteConexao | Teste | verifica a conexao antes das telas |

## Regras de negocio
- Venda e itens sao gravados em uma unica transacao (commit/rollback).
- O valor unitario dos itens e o total da venda sao lidos/calculados a partir de TBPRODUTO, nao da tela.
- Vender baixa o estoque (qtdprod); excluir a venda devolve a quantidade. Estoque insuficiente cancela a venda.
- Cliente com vendas e produto presente em vendas nao podem ser excluidos (chave estrangeira).
- CPF deve seguir 000.000.000-00 e e unico.
